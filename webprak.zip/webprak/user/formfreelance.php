<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
        integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="style/style.css">
    <title>Home</title>
    <style>
         .home {
            display: flex;
            align-items: center;
            gap: 15px;
            padding-top: 55px;
        }

        .hero {
            width: 100%;
            min-height: 100vh;
            background: white;
        }

        nav {
            background: #73a3eb;
            width: 100%;
            padding: 15px 5%;
            display: flex;
            align-items: center;
            justify-content: space-between;
            position: relative;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
        }

        .logo {
            width: auto;
            height: 70px;
        }

        .userpict {
            width: auto;
            height: 60px;
            border-radius: 50%;
            border: solid 2px white;
            cursor: pointer;
            margin-left: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
        }

        .coverimage img {
            width: 750px;
            margin-left: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
        }

        ul {
            list-style: none;
            text-align: right;
            margin-left:250px;
        }

        ul li {
            display: inline-block;
            position: relative;
            margin: 5px 10px;
            left: 15%;
            padding: 8px;
        }

        ul li a {
            /* display: block; */
            color: white;
            text-decoration: none;
            text-align: center;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
        }

        ul li a:after {
            content: '';
            display: block;
            width: 0;
            height: 2px;
            background: white;
            transition: width 0.3s;
        }

        ul li a:hover:after,
        ul li a:focus:after {
            width: 100%;
        }
        
        nav .logo {
            background-color: white;
            height: 53px;
            border-radius: 7px;
            box-shadow: 0 2px 4px rgba(0, 0, 4, 0.5)
        }

        .container2 {
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 90vh;
            margin-left: auto;
            gap: 190px;
        }

        .form-box2 {
            background-color: #d9e8ff;
            padding: 10px 0;
            display: flex;
            margin-left: 110px;
            flex-direction: column;
            padding: 15px 15px;
            border-radius: 20px;
            box-shadow: 0 0 128px 0 rgb(0, 0, 0, 0.1),
                0 32px 64px -48px rgb(0, 0, 0, 0.8);
        }

        .form-box2 .field.input input[type="date"] {
            width: 155%;
        }

        form .column {
            display: flex;
            column-gap: 15px;
        }

        .form-box2 h2 {
            font-size: 20px;
            font-weight: 700;
            padding-bottom: 30px;
            text-decoration: underline;
            text-align: center;
            color: black;
        }

        .form-box2 .field {
            font-weight: 600;
            display: flex;
            margin-bottom: 25px;
            padding-right: 75px;
            padding-left: 5px;
            flex-direction: column;
            color: #084e88;
        }

        .form-box2 .input input {
            height: 35px;
            width: 130%;
            font-size: 14px;
            padding: 0 25px;
            border-radius: 5px;
            border: 1px solid #ccc;
            outline: none;
        }

        .form-box2 .input select {
            height: 35px;
            font-size: 14px;
            padding: 0 25px;
            border-radius: 5px;
            border: 1px solid #ccc;
            outline: none;
        }

        .column .field.input select.form {
            height: 35px;
            width: 140%;
            font-size: 14px;
            padding: 0 25px;
            border-radius: 5px;
            border: 1px solid #ccc;
            outline: none;
        }

        .column .field.input select.form option {
            height: 35px;
            width: 130%;
            font-size: 14px;
            padding: 0 25px;
            border-radius: 5px;
            border: 1px solid #ccc;
            outline: none;
        }

        .btn2 {
            height: 40px;
            width: 30%;
            background-color: #084e88;
            margin-left: 250px;
            color: #ffffff;
            border: none;
            border-radius: 5px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .btn2:hover {
            opacity: 0.82;
        }

        span {
            color: #084e88;
        }

    </style>
</head>

<body>
    <div class="navbar">
        <nav>
            <img src="images/logo_freelancer.png" class="logo">
            <ul>
                <li><a href="home.php">Home</a></li>
                <li><a href="job.php">Job</a></li>
                <li><a href="appliedjob.php">Applied Job</a></li>
                <li><a href="jobdone.php">Finished Job</a></li>
                <li><a href="../index.php">Logout</a></li>
            </ul>
            <img src="images/unisex.jpg" class="userpict">
        </nav>
    </div>

    <div class="container2">
        <?php
        include 'php/config.php';

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        if (isset($_GET['project_id'])) {
            $project_id = $_GET['project_id'];

            $sql_project_detail = "SELECT projects.*, clients.name AS name
                                   FROM projects JOIN clients ON projects.client_id = clients.id 
                                   WHERE projects.id = $project_id";

            $result_project_detail = $conn->query($sql_project_detail);

            if ($result_project_detail->num_rows > 0) {
                $project_detail = $result_project_detail->fetch_assoc();
        ?>
                <div class="form-box2">
                    <h2>Job<span> Application Form</span></h2>
                    <form action="" method="post">
                        <input type="hidden" name="status" id="status" value="">
                        <div class="column">
                            <div class="field input">
                                <label for="user">Name</label>
                                <input type="text" name="freelancer" id="user" placeholder="Enter your name" required>
                            </div>
                            <div class="field input">
                                <label for="email">Email</label>
                                <input type="text" name="email" id="email" placeholder="Enter your email" required>
                            </div>
                        </div>
                        <div class="column">
                            <div class="field input">
                                <label for="gender">Gender</label>
                                <select class="form select" name="gender" id="gender" required>
                                    <option value="" disabled selected>Select your gender</option>
                                    <option value="Female">Female</option>
                                    <option value="Male">Male</option>
                                </select>
                            </div>
                            <div style="margin-left:20px" class="field input">
                                <label for="portfolio">Portfolio</label>
                                <input type="text" name="portfolio" id="portfolio" placeholder="Enter your portfolio" required>
                            </div>
                        </div>
                        <div class="column">
                            <div class="field input">
                                <label for="date">Date Birth</label>
                                <input type="date" name="date_birth" id="date" required>
                            </div>
                            <div style="margin-left:39px" class="field input">
                                <label for="title">Job</label>
                                <input type="text" name="title" id="title" value="<?php echo $project_detail['title']; ?>" readonly required>
                            </div>
                        </div>
                        <div class="column">
                            <div class="field input">
                                <label for="phone">Phone</label>
                                <input type="text" name="phone" id="phone" placeholder="Enter your phone" required>
                            </div>
                            <div class="field input">
                                <label for="description">Description</label>
                                <input type="text" name="description" id="description" value="<?php echo $project_detail['description']; ?>" readonly required>
                            </div>
                        </div>
                        <div class="column">
                            <div class="field input">
                                <label for="skills">Skill</label>
                                <input type="text" name="skills" id="skills" placeholder="Enter your skills" required>
                            </div>
                            <div class="field input">
                                <label for="name">Company</label>
                                <input type="text" name="name" id="name" value="<?php echo $project_detail['name']; ?>" readonly required>
                            </div>
                        </div>
                        <div class="field2">
                            <input type="submit" class="btn2" name="simpan" value="Submit">
                        </div>
                    </form>
                    <?php
                    if (isset($_POST['simpan'])) {
                        $freelancer = $_POST['freelancer'];
                        $skills = $_POST['skills'];
                        $gender = $_POST['gender'];
                        $email = $_POST['email'];
                        $date_birth = $_POST['date_birth'];
                        $portfolio = $_POST['portfolio'];
                        $phone = $_POST['phone'];
                        $project_title = $_POST['title'];
                        $project_description = $_POST['description'];
                        $project_name = $_POST['name'];
                        $status = $_POST['status'];

                        // Upsert freelancer
                        $sql_upsert_freelancer = "INSERT INTO freelancers (name, skills, gender, email, date_birth, portfolio, phone) 
                                                  VALUES ('$freelancer', '$skills', '$gender', '$email', '$date_birth', '$portfolio', '$phone')
                                                  ON DUPLICATE KEY UPDATE 
                                                  name=VALUES(name), skills=VALUES(skills), gender=VALUES(gender), 
                                                  date_birth=VALUES(date_birth), portfolio=VALUES(portfolio), phone=VALUES(phone)";
                        $conn->query($sql_upsert_freelancer);

                        // Insert into appliedjob
                        $sql_appliedjob = "INSERT INTO appliedjob (freelancer, skills, gender, email, date_birth, portfolio, phone, title, description, name, status) 
                                           VALUES ('$freelancer', '$skills', '$gender', '$email', '$date_birth', '$portfolio', '$phone', '$project_title', '$project_description', '$project_name', '$status')";

                        if ($conn->query($sql_appliedjob) === TRUE) {
                            echo "<script>alert('Form application job created successfully');</script>";
                            echo "<script>window.location.href = 'job.php';</script>";
                        } else {
                            echo "Error: " . $sql_appliedjob . "<br>" . $conn->error;
                        }
                        $conn->close();
                    }
                    ?>
                </div>
        <?php
            } else {
                echo "Project not found.";
            }
        } else {
            echo "Project ID is not provided.";
        }
        ?>
    </div>
    <script>
        let subMenu = document.getElementById("subMenu");
        function toggleMenu() {
            subMenu.classList.toggle("open-menu");
        }
    </script>
</body>

</html>
