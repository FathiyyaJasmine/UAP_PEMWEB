<?php
include 'php/config.php';

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query untuk mengambil data dari tabel appliedjob
$sql = "SELECT appliedjob.id, appliedjob.name, appliedjob.title, appliedjob.description, appliedjob.status
        FROM appliedjob";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    ?>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Data Jobs</title>
        <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
            integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A=="
            crossorigin="anonymous" referrerpolicy="no-referrer" />
        <link rel="stylesheet" href="style/table.css">
    </head>

    <body>
        <div class="navbar">
            <nav>
                <img src="images/logo_freelancer.png" class="logo">
                <ul>
                    <li><a href="home.php">Home</a></li>
                    <li><a href="job.php">Job</a></li>
                    <li><a href="appliedjob.php">Applied Job</a></li>
                    <li><a href="jobdone.php">Finished Job</a></li>
                    <li><a href="../index.php">Logout</a></li>
                </ul>
                <img src="images/unisex.jpg" class="userpict">
            </nav>
        </div>

        <div class="main-content">
            <header>
                <h2 class="judul">Data Jobs</h2>
            </header>
            <div class="content">
                <div class="table-wrapper">
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Company</th>
                                <th>Job</th>
                                <th>Description</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            // Loop through each row of the result set
                            while ($row = $result->fetch_assoc()) {
                                ?>
                                <tr>
                                    <td><?= $row['id'] ?></td>
                                    <td><?= $row['name'] ?></td>
                                    <td><?= $row['title'] ?></td>
                                    <td><?= $row['description'] ?></td>
                                    <td><?= $row['status'] ?></td>
                                </tr>
                                <?php
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </body>

    </html>
    <?php
} else {
    echo "No data found.";
}

// Close the connection
$conn->close();
?>
