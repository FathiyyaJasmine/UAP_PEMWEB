<?php
include 'php/config.php';

$id = $_GET['id'];
$sql = "DELETE FROM jobdone WHERE id=$id";
if (mysqli_query($conn, $sql)) {
    header('Location: jobdone.php');
} else {
    echo "Error: " . mysqli_error($conn);
}
?>
