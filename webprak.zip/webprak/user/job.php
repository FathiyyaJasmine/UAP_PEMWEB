<?php
include 'php/config.php';

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Ambil data klien
$sql_clients = "SELECT * FROM clients";
$result_clients = $conn->query($sql_clients);

// Ambil data proyek
$sql_projects = "SELECT projects.id, projects.title, clients.name, clients.image
                 FROM projects JOIN clients ON projects.client_id = clients.id";
$result_projects = $conn->query($sql_projects);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
        integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://unpkg.com/boxicons@latest/css/boxicons.min.css">
    <link rel="stylesheet" href="style/style.css">
    <title>Home</title>
    <style>
        .home {
            display: flex;
            align-items: center;
            gap: 15px;
            padding-top: 55px;
        }

        .hero {
            width: 100%;
            min-height: 100vh;
            background: white;
        }

        nav {
            background: #73a3eb;
            width: 100%;
            padding: 5px 5%;
            display: flex;
            align-items: center;
            justify-content: space-between;
            position: relative;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
        }

        .logo {
            width: auto;
            height: 70px;
        }

        .userpict {
            width: auto;
            height: 60px;
            border-radius: 50%;
            border: solid 2px white;
            cursor: pointer;
            margin-left: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
        }

        .coverimage img {
            width: 750px;
            margin-left: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
        }


        ul {
            list-style: none;
            text-align: right;
        }

        ul li {
            display: inline-block;
            position: relative;
            margin: 5px 10px;
            left: 15%;
        }

        ul li a {
            display: block;
            padding: 20px 25px;
            color: white;
            text-decoration: none;
            text-align: center;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
        }

        ul li a:after {
            content: '';
            display: block;
            width: 0;
            height: 2px;
            background: white;
            transition: width 0.3s;
        }

        ul li a:hover:after,
        ul li a:focus:after {
            width: 100%;
        }

        nav .logo {
            background-color: white;
            height: 53px;
            border-radius: 7px;
            box-shadow: 0 2px 4px rgba(0, 0, 4, 0.5)
        }

        .container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            align-items: center;
        }

        .card {
            width: 350px;
            margin: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgb(0, 0, 0, 0.2);
            overflow: hidden;
        }

        .card-image img {
            padding: 8px;
            width: 85%;
            height: auto;
            border-radius: 15px;
            margin-left: 28px;
            margin-top: 20px;
        }

        .content {
            padding: 20px;
        }

        .content h3 {
            font-size: 26px;
            margin-bottom: 10px;
        }

        .content p {
            font-size: 15px;
        }

        .content .btn {
            display: inline-block;
            padding: 10px 20px;
            background-color: #084e88;
            box-shadow: 0 0 10px rgb(0, 0, 0, 0.2);
            color: white;
            margin-top: 12px;
            font-weight: 600;
            text-decoration: none;
            border-radius: 4px;
            transition: 0.3s ease;
        }

        .card:hover {
            transform: scale(1.05);
        }

        .card-image {
            width: 100%;
        }
    </style>
</head>

<body>
    <div class="navbar">
        <nav>
            <img src="images/logo_freelancer.png" class="logo">
            <ul>
                <li><a href="home.php">Home</a></li>
                <li>
                    <a href="job.php">Job</a>
                </li>
                <li>
                    <a href="appliedjob.php">Applied Job</a>
                </li>
                <li>
                    <a href="jobdone.php">Finished Job</a>
                </li>
                <li>
                    <a href="../index.php">Logout</a>
                </li>
            </ul>
            <img src="images/unisex.jpg" class="userpict" onclick="toggleMenu()">
        </nav>
    </div>

    <div class="container">
        <?php while ($row = $result_projects->fetch_assoc()) { ?>
            <div class="card">
                <div class="card-image">
                    <img src="data:image/jpeg;base64,<?= base64_encode($row['image']) ?>">
                </div>
                <div class="content">
                    <h4><?php echo $row['name']; ?></h4>
                    <p><?php echo $row['title']; ?></p>
                    <a href='detailjob.php?project_id=<?php echo $row["id"]; ?>' class='btn'>See More</a>
                </div>
            </div>
        <?php } ?>
    </div>


    <script>
        let subMenu = document.getElementById("subMenu");
        function toggleMenu() {
            subMenu.classList.toggle("open-menu");
        }
    </script>
</body>

</html>