<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style\style.css">
    <title>Registration</title>
    <style>
        <style>
        * {
            padding: 0;
            margin: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
            transition: all .2s ease-out;
        }

        body {
            background-color: white;
        }

        .container {
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 90vh;
        }

        .form-box {
            background-color: #73a3eb;
            display: flex;
            flex-direction: column;
            padding: 25px 55px;
            border-radius: 20px;
            box-shadow: 0 0 128px 0 rgb(0, 0, 0, 0.1),
                0 32px 64px -48px rgb(0, 0, 0, 0.5);
        }

        .form-box header {
            font-size: 25px;
            font-weight: 600;
            padding-bottom: 25px;
            text-align: center;
            color: white;
        }

        .form-box .field {
            display: flex;
            margin-bottom: 10px;
            padding-right: 75px;
            padding-left: 5px;
            flex-direction: column;
            color: white;
        }

        .form-box .input input {
            height: 40px;
            width: 130%;
            font-size: 14px;
            padding: 0 18px;
            border-radius: 5px;
            border: 1px solid #ccc;
            outline: none;
        }

        .btn {
            height: 35px;
            width: 100px;
            background-color: #084e88;
            left: 50px;
            margin-left: auto;
            margin-right: 10px;
            border: 0;
            border-radius: 5px;
            color: #ffffff;
            font-size: 15px;
            font-weight: 600;
        }

        .btn:hover {
            opacity: 0.82;
        }

        .submit {
            width: 100%;
        }

        .link {
            font-size: 12px;
            text-align: center;
            color: white;
        }

        .link a {
            color: white;
        }
    </style>
    </style>
</head>

<body>
    <div class="container">
        <div class="form-box">

            <?php
            include ("php/config.php");
            if (isset($_POST['submit'])) {
                $first_name = $_POST['first_name'];
                $last_name = $_POST['last_name'];
                $username = $_POST['username']; // Change 'username' to 'email'
                $password = $_POST['password'];

                $verifiy_query = mysqli_query($conn, "SELECT Username FROM registrasi WHERE Username = '$username' ");

                if (mysqli_num_rows($verifiy_query) != 0) {
                    echo "<div class='message'>
                      <p>This username is used, Try another!</p>
                 </div> <br>";
                    echo "<a href='javascript:self.history.back()'><button class='btn'>Go Back</button></a>";
                } else {
                    mysqli_query($conn, "INSERT INTO registrasi(First_Name, Last_Name, Username, Password) VALUES ('$first_name','$last_name','$username','$password')") or die("Error Occured");
                    echo "<div class='message'>
                      <p>Registration successfully!</p>
                 </div> <br>";
                    echo "<a href='login.php'><button class='btn'>Login</button></a>";
                }

            } else {
                ?>
                <header>Registration</header>
                <form action="" method="post">
                    <div class="field input">
                        <label for="firstname">First Name</label>
                        <input type="text" name="first_name" id="firstname" placeholder="Enter your first name" required>
                    </div>
                    <div class="field input">
                        <label for="lastname">Last Name</label>
                        <input type="text" name="last_name" id="lastname" placeholder="Enter your last name" required>
                    </div>
                    <div class="field input">
                        <label for="username">Username</label>
                        <input type="text" name="username" id="username" placeholder="Enter your username" required>
                    </div>
                    <div class="field input">
                        <label for="password">Password</label>
                        <input type="password" name="password" id="password" placeholder="Enter your password" required>
                    </div>
                    <div class="field">
                        <input type="submit" class="btn" name="submit" value="Sign Up">
                    </div>
                    <div class="link">
                        <p>Already have an account?<a href="login.php">Login</a></p>
                    </div>
                </form>
            </div>
        <?php } ?>
    </div>
</body>

</html>