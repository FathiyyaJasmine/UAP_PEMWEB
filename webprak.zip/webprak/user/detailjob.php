<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <title>Home</title>
    <style>
        .home {
            display: flex;
            align-items: center;
            gap: 15px;
            padding-top: 55px;
        }

        .hero {
            width: 100%;
            min-height: 100vh;
            background: white;
        }

        nav {
            background: #73a3eb;
            width: 100%;
            padding: 5px 5%;
            display: flex;
            align-items: center;
            justify-content: space-between;
            position: relative;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
        }

        .logo {
            width: auto;
            height: 70px;
        }

        .userpict {
            width: auto;
            height: 60px;
            border-radius: 50%;
            border: solid 2px white;
            cursor: pointer;
            margin-left: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
        }

        .coverimage img {
            width: 750px;
            margin-left: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
        }


        ul {
            list-style: none;
            text-align: right;
        }

        ul li {
            display: inline-block;
            position: relative;
            margin: 5px 10px;
            left: 15%;
        }

        ul li a {
            display: block;
            padding: 20px 25px;
            color: white;
            text-decoration: none;
            text-align: center;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
        }

        ul li a:after {
            content: '';
            display: block;
            width: 0;
            height: 2px;
            background: white;
            transition: width 0.3s;
        }

        ul li a:hover:after,
        ul li a:focus:after {
            width: 100%;
        }

        nav .logo {
            background-color: white;
            height: 53px;
            border-radius: 7px;
            box-shadow: 0 2px 4px rgba(0, 0, 4, 0.5)
        }
        
        span {
            color: #084e88;
        }

        h2 {
            padding-bottom: 30px;
            font-weight: 800;
            text-decoration: underline;
            text-align: center;
            margin-top: 20px;
            margin-bottom: 20px;
        }

        .btn {
            background-color: #084e88;
            color: white;
            font-weight: 600;
            width: 150px;
            height: 40px;
            align-content: center;
            margin-bottom: 40px;
            margin-left: 500px;
            box-shadow: 0 2px 4px rgba(0, 0, 4, 0.5)
        }
    </style>
</head>

<body>
    <div class="navbar">
        <nav>
            <img src="images/logo_freelancer.png" class="logo">
            <ul>
                <li><a href="home.php">Home</a></li>
                <li><a href="job.php">Job</a></li>
                <li><a href="appliedjob.php">Applied Job</a></li>
                <li><a href="jobdone.php">Finished Job</a></li>
                <li><a href="../index.php">Logout</a></li>
            </ul>
            <img src="images/unisex.jpg" class="userpict">
        </nav>
    </div>

    <div class="container">
        <?php
        include 'php/config.php';

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Ambil project_id dari URL query string
        if (isset($_GET['project_id'])) {
            $project_id = $_GET['project_id'];

            // Query untuk mendapatkan detail proyek berdasarkan project_id
            $sql_project_detail = "SELECT projects.*, clients.name AS name, clients.email, clients.phone, clients.address 
            FROM projects JOIN clients ON projects.client_id = clients.id 
            WHERE projects.id = $project_id";

            $result_project_detail = $conn->query($sql_project_detail);

            if ($result_project_detail->num_rows > 0) {
                $project_detail = $result_project_detail->fetch_assoc();
                ?>
                <div class="container4">
                    <div class="row justify-content-center">
                        <div class="col-md-10 mb-5">
                            <h2>Project <span>Detail</span></h2>
                            <h4>Details Job:</h4>
                            <table class="table table-bordered" width="500px">
                                <tr>
                                    <th>Company :</th>
                                    <td><?php echo $project_detail['name']; ?></td>
                                </tr>
                                <tr>
                                    <th>Project Name :</th>
                                    <td><?php echo $project_detail['title']; ?></td>
                                </tr>
                                <tr>
                                    <th>Description :</th>
                                    <td><?php echo $project_detail['description']; ?></td>
                                </tr>
                                <tr>
                                    <th>Email :</th>
                                    <td><?php echo $project_detail['email']; ?></td>
                                </tr>
                                <tr>
                                    <th>Phone :</th>
                                    <td><?php echo $project_detail['phone']; ?></td>
                                </tr>
                                <tr>
                                    <th>Address :</th>
                                    <td><?php echo $project_detail['address']; ?></td>
                                </tr>
                                <tr>
                                    <th>Budget :</th>
                                    <td>Rp <?php echo $project_detail['budget']; ?></td>
                                </tr>
                                <tr>
                                    <th>Deadline:</th>
                                    <td><?php echo $project_detail['deadline']; ?></td>
                                </tr>
                            </table>
                        </div>
                    </div>
                    <a href="formfreelance.php?project_id=<?php echo $project_detail['id']; ?>" class="btn">APPLY</a>
                </div>
            </div>
            <?php
            } else {
                echo "Project not found.";
            }
        } else {
            echo "Project ID is not provided.";
        }
        ?>
    </div>

    <script>
        let subMenu = document.getElementById("subMenu");

        function toggleMenu() {
            subMenu.classList.toggle("open-menu");
        }
    </script>
</body>

</html>