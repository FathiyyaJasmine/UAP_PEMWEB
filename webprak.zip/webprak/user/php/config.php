<?php
$conn = mysqli_connect("localhost", "root","", "freelance_platform") or die("Couldn't connect to server");
?>