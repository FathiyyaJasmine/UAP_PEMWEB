<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $freelancer_id = $_POST['freelancer_id'];
    $project_id = $_POST['project_id'];
    $status = $_POST['status'];

    $sql = "INSERT INTO jobs (title, description, freelancer_id, project_id, status) VALUES ('$title', '$description', '$freelancer_id', '$project_id', '$status')";
    
    if (mysqli_query($conn, $sql)) {
        header('Location: index_jobs.php');
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}

// Fetch freelancers and projects for dropdowns
$freelancers = mysqli_query($conn, "SELECT * FROM freelancers");
$projects = mysqli_query($conn, "SELECT * FROM projects");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Job</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .form-container {
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            border: 1px solid #dee2e6;
            border-radius: 8px;
            background-color: #d9e8ff;
        }
        .form-container .btn-container {
            display: flex;
            justify-content: center;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="form-container">
    <h2>Create Job</h2>
    <form method="post">
        <div class="form-group">
            <label>Title</label>
            <input type="text" name="title" class="form-control" required>
        </div>
        <div class="form-group">
            <label>Description</label>
            <textarea name="description" class="form-control" required></textarea>
        </div>
        <div class="form-group">
            <label>Freelancer</label>
            <select name="freelancer_id" class="form-control" required>
                <?php while($freelancer = mysqli_fetch_assoc($freelancers)): ?>
                    <option value="<?= $freelancer['id'] ?>"><?= $freelancer['name'] ?></option>
                <?php endwhile; ?>
            </select>
        </div>
        <div class="form-group">
            <label>Project</label>
            <select name="project_id" class="form-control" required>
                <?php while($project = mysqli_fetch_assoc($projects)): ?>
                    <option value="<?= $project['id'] ?>"><?= $project['title'] ?></option>
                <?php endwhile; ?>
            </select>
        </div>
        <div class="form-group">
            <label>Status</label>
            <select name="status" class="form-control" required>
                <option value="Pending">Pending</option>
                <option value="In Progress">In Progress</option>
                <option value="Completed">Completed</option>
            </select>
        </div>
        <div class="form-group btn-container">
            <button type="submit" class="btn btn-primary">Submit</button>
        </div>
    </form>
    </div>
</div>
</body>
</html>
