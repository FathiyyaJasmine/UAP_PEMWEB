<?php
include 'config.php';

$id = $_GET['id'];
$sql = "DELETE FROM clients WHERE id=$id";
if (mysqli_query($conn, $sql)) {
    header('Location: index_clients.php');
} else {
    echo "Error: " . mysqli_error($conn);
}
?>