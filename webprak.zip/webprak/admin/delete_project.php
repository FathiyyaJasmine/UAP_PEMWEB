<?php
include 'config.php';

$id = $_GET['id'];
$sql = "DELETE FROM projects WHERE id=$id";
if (mysqli_query($conn, $sql)) {
    header('Location: index_project.php');
} else {
    echo "Error: " . mysqli_error($conn);
}
?>
