<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $gender = $_POST['gender'];
    $date_birth = $_POST['date_birth'];
    $skills = $_POST['skills'];
    $portfolio = $_POST['portfolio'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];

    $sql = "INSERT INTO freelancers (name, gender, date_birth, skills, portfolio, email, phone) VALUES ('$name', '$gender', '$date_birth', '$skills', '$portfolio', '$email', '$phone')";
    if (mysqli_query($conn, $sql)) {
        header('Location: index_freelancer.php');
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <title>Freelance Platform</title>
    <style>
        .form-container {
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            border: 1px solid #dee2e6;
            border-radius: 8px;
            background-color: #d9e8ff;
        }
        .form-container .btn-container {
            display: flex;
            justify-content: center;
        }
    </style>
</head>
<body>
    
<div class="container">
    <div  class="form-container">
    <h2>Add Freelancer</h2>
    <form method="post">
        <div class="form-group">
            <label>Name</label>
            <input type="text" name="name" class="form-control" required>
        </div>
        <div class="form-group">
            <label>Gender</label>
            <input type="text" name="gender" class="form-control" required>
        </div>
        <div class="form-group">
            <label>Date Birth</label>
            <input type="date" name="date_birth" class="form-control" required>
        </div>
        <div class="form-group">
            <label>Skills</label>
            <textarea name="skills" class="form-control" required></textarea>
        </div>
        <div class="form-group">
            <label>Portfolio</label>
            <textarea name="portfolio" class="form-control"></textarea>
        </div>
        <div class="form-group">
            <label>Email</label>
            <input type="email" name="email" class="form-control" required>
        </div>
        <div class="form-group">
            <label>Phone</label>
            <input type="text" name="phone" class="form-control">
        </div>
        <div class="form-group btn-container">
            <button type="submit" class="btn btn-primary">Submit</button>
        </div>
    </form>
    </div>
</div>
</body>
</html>
