<?php
include 'config.php';

$id = $_GET['id'];
$sql = "DELETE FROM freelancers WHERE id=$id";
if (mysqli_query($conn, $sql)) {
    header('Location: index_freelancer.php');
} else {
    echo "Error: " . mysqli_error($conn);
}
?>
