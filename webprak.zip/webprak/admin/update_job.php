<?php
include 'config.php';

$id = $_GET['id'];
$result = mysqli_query($conn, "SELECT * FROM jobs WHERE id=$id");
$row = mysqli_fetch_assoc($result);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $status = $_POST['status'];

    $sql = "UPDATE appliedjob SET status='$status' WHERE id=$id";
    
    if (mysqli_query($conn, $sql)) {
        header('Location: index_job.php'); // Redirect to index_jobs.php after update
        exit(); // Ensure no further code is executed after the redirect
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Job</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .form-container {
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            border: 1px solid #dee2e6;
            border-radius: 8px;
            background-color: #d9e8ff;
        }
        .form-container .btn-container {
            display: flex;
            justify-content: center;
        }
    </style>
</head>
<body>
<div class="container">
    <div class="form-container">
    <h2>Edit Job</h2>
    <form method="post">
        <div class="form-group">
            <label>Status</label>
            <select name="status" class="form-control" required>
                <option value="Pending" <?= ($row['status'] == 'Pending') ? 'selected' : '' ?>>Pending</option>
                <option value="Accept" <?= ($row['status'] == 'Accept') ? 'selected' : '' ?>>Accept</option>
                <option value="Decline" <?= ($row['status'] == 'Decline') ? 'selected' : '' ?>>Decline</option>
            </select>
        </div>
        <div class="form-group btn-container">
            <button type="submit" class="btn btn-primary">Submit</button>
        </div>
    </form>
    </div> 
</div>
</body>
</html>
