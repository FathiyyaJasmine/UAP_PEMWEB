<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $budget = $_POST['budget'];
    $deadline = $_POST['deadline'];
    $client_id = $_POST['client_id'];

    $sql = "INSERT INTO projects (title, description, budget, deadline, client_id) VALUES ('$title', '$description', $budget, '$deadline', $client_id)";
    if (mysqli_query($conn, $sql)) {
        header('Location: index_project.php');
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <title>Add Project</title>
    <style>
        .form-container {
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            border: 1px solid #dee2e6;
            border-radius: 8px;
            background-color: #d9e8ff;
        }
        .form-container .btn-container {
            display: flex;
            justify-content: center;
        }
    </style>
</head>
<body>
<div class="container">
    <div class="form-container">
    <h2>Add Project</h2>
    <form method="post">
        <div class="form-group">
            <label>Title</label>
            <input type="text" name="title" class="form-control" required>
        </div>
        <div class="form-group">
            <label>Description</label>
            <textarea name="description" class="form-control" required></textarea>
        </div>
        <div class="form-group">
            <label>Budget</label>
            <input type="text" name="budget" class="form-control" required>
        </div>
        <div class="form-group">
            <label>Deadline</label>
            <input type="date" name="deadline" class="form-control" required>
        </div>
        <div class="form-group">
            <label>Client ID</label>
            <input type="text" name="client_id" class="form-control" required>
        </div>
        <div class="form-group btn-container">
                <button type="submit" class="btn btn-primary">Create Project</button>
        </div>
    </form>
    </div>
</div>

</body>
</html>
