<?php
include 'config.php';

// Tentukan jumlah data per halaman
$limit = 10;

// Tentukan halaman saat ini, jika tidak ada yang ditentukan, defaultnya adalah halaman 1
$page = isset($_GET['page']) ? $_GET['page'] : 1;

// Hitung offset
$offset = ($page - 1) * $limit;

// Query untuk mendapatkan data yang sesuai dengan limit dan offset
$result = mysqli_query($conn, "SELECT * FROM freelancers LIMIT $limit OFFSET $offset");

// Query untuk menghitung jumlah total data
$total_results = mysqli_query($conn, "SELECT COUNT(*) as total FROM freelancers");
$total_row = mysqli_fetch_assoc($total_results)['total'];
$total_pages = ceil($total_row / $limit);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Freelancers</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="data_table.css">
</head>
<body>
<div class="navbar">
        <nav>
            <img src="assets/logo_freelancer.png" class="logo">
            <ul>
                <li><a href="home_admin.php">Home</a></li>
                <li>
                    <a href="index_clients.php">Company List</a>
                </li>
                <li>
                    <a href="index_job.php">Job List</a>
                </li>
                <li>
                    <a href="index_freelancer.php">Freelancer List</a>
                </li>
                <li>
                    <a href="index_project.php">Project List</a>
                </li>
                <li>
                    <a href="../index.php">Logout</a>
                </li>
            </ul>
            <img src="assets/admin.jpeg" class="userpict">
        </nav>
    </div>
    
    <div class="main-content">
        <header>
            <h2 class="judul">Data Freelancers</h2>
        </header>
        <div class="content">
            <div class="search-and-button">
                <div class="btn btn-tambah left">
                    <a href="create_freelancer.php">Tambah</a>
                </div>
            </div>
            <div class="table-wrapper">
                <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Gender</th>
                        <th>Date Birth</th>
                        <th>Skills</th>
                        <th>Portfolio</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                    <tbody>
                        <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                            <tr>
                                <td><?= $row['id'] ?></td>
                                <td><?= $row['name'] ?></td>
                                <td><?= $row['gender'] ?></td>
                                <td><?= $row['date_birth'] ?></td>
                                <td><?= $row['skills'] ?></td>
                                <td><?= $row['portfolio'] ?></td>
                                <td><?= $row['email'] ?></td>
                                <td><?= $row['phone'] ?></td>
                                <td>
                                    <a href="update_freelancer.php?id=<?= $row['id'] ?>" class="btn btn-primary">Edit</a>
                                    <a href="delete_freelancer.php?id=<?= $row['id'] ?>" class="btn btn-danger">Delete</a>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
            <!-- Pagination -->
            <div class="pagination">
                <?php if ($page > 1): ?>
                    <a href="?page=<?= $page - 1 ?>">&laquo; Previous</a>
                <?php endif; ?>
                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <a href="?page=<?= $i ?>" class="<?= $i == $page ? 'active' : '' ?>"><?= $i ?></a>
                <?php endfor; ?>
                <?php if ($page < $total_pages): ?>
                    <a href="?page=<?= $page + 1 ?>">Next &raquo;</a>
                <?php endif; ?>
            </div>
    </div>
</body>
</html>
