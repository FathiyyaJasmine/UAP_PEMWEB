<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://unpkg.com/boxicons@latest/css/boxicons.min.css">
    <link rel="stylesheet" href="data_table.css">
    <title>Home</title>
    <style>
        .home {
            display: flex;
            align-items: center;
            gap: 15px;
            padding-top: 55px;
        }

        .hero {
            width: 100%;
            min-height: 100vh;
            background: white;
        }

        nav {
            background: #73a3eb;
            width: 100%;
            padding: 5px 5%;
            display: flex;
            align-items: center;
            justify-content: space-between;
            position: relative;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
        }

        .logo {
            width: auto;
            height: 70px;
        }

        .userpict {
            width: auto;
            height: 60px;
            border-radius: 50%;
            border: solid 2px white;
            cursor: pointer;
            margin-left: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
        }

        .coverimage img {
            width: 750px;
            margin-left: 20px;
        }


        ul {
            list-style: none;
            text-align: right;
        }

        ul li {
            display: inline-block;
            position: relative;
            margin: 5px 10px;
            left: 15%;
        }

        ul li a {
            display: block;
            padding: 20px 25px;
            color: white;
            text-decoration: none;
            text-align: center;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
        }

        ul li a:after {
            content: '';
            display: block;
            width: 0;
            height: 2px;
            background: white;
            transition: width 0.3s;
        }

        ul li a:hover:after,
        ul li a:focus:after {
            width: 100%;
        }

        nav .logo {
            background-color: white;
            height: 53px;
            border-radius: 7px;
            box-shadow: 0 2px 4px rgba(0, 0, 4, 0.5)
        }


        .about-section {
            width: 100%;
            padding: 100px 40px;
            box-sizing: border-box;
            background-color: #d9e8ff;
        }

        .about img1 {
            height: auto;
            width: 500px;
        }

        .about-text {
            width: 550px;
        }

        .main-about {
            width: 100%;
            max-width: 100%;
            margin: 0 auto;
            display: flex;
            align-items: center;
            justify-content: space-around;
        }

        .about-text h1 {
            font-size: 50px;
            text-decoration: underline;
            color: #4D869C;
        }

        .about-text h3 {
            font-size: 22px;
            display: inline-block;
            color: #4D869C;
            margin-bottom: 10px;
        }

        .about-text p {
            font-size: 17px;
            display: inline-block;
            color: rgb(212, 212, 231);
        }

        button:hover {
            background-color: #5b78c7;
        }

        .container-section {
            width: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
            margin-top: 30px;
        }

        .container-section .contactInfo {
            width: 50%;
            display: flex;
            flex-direction: column;
        }

        .container-section .contactInfo .box {
            position: relative;
            padding: 20px 0;
            display: flex;
        }

        .container-section .contactInfo .box .icon {
            width: 50px;
            height: 50px;
            background-color: white;
            padding-top: 10px;
            display: flex;
            text-align: center;
            justify-content: center;
            font-size: 30px;
            border-radius: 100%;
            border: 3px solid #4D869C;
        }

        .text {
            display: flex;
            margin-left: 20px;
            font-size: 16px;
            display: flex;
            flex-direction: column;
        }

        .text h3 {
            color: black;
        }

        .text p {
            color: black;
        }

        .medsos-section {
            width: 100%;
            padding-top: 35px;
            padding-bottom: 350px;
            box-sizing: border-box;
            background-color: white;

        }

        .medsos-text h1 {
            text-align: center;
            font-weight: 800;
            font-size: 40px;
            text-decoration: underline;
            color: #4D869C;
        }

        .medsos-section ul {
            position: absolute;
            left: 50%;
            padding: 0;
            justify-content: center;
            margin: 0;
            transform: translate(-62%, -45%);
            display: flex;

        }

        .medsos-section ul li {
            list-style: none;
            margin: 20px;
        }

        .medsos-section ul li .fa-brands {
            font-size: 50px;
            padding-top: 300px;
            line-height: 60px;
            transition: .6s;
            color: #031930;
        }

        .medsos-section ul li a {
            width: 60px;
            height: 60px;
            border-radius: 100%;
            background-color: #cfd5db;
            text-align: center;
            box-shadow: 0 5px 4px rgb(0, 0, 0, .5);
        }

        .medsos-section ul li a:hover {
            transform: translate(0, -10px)
        }

        span {
            color: black;
        }
    </style>
</head>

<body>
    <div class="navbar">
        <nav>
            <img src="assets/logo_freelancer.png" class="logo">
            <ul>
                <li><a href="home_admin.php">Home</a></li>
                <li>
                    <a href="index_clients.php">Company List</a>
                </li>
                <li>
                    <a href="index_job.php">Job List</a>
                </li>
                <li>
                    <a href="index_freelancer.php">Freelancer List</a>
                </li>
                <li>
                    <a href="index_project.php">Project List</a>
                </li>
                <li>
                    <a href="../index.php">Logout</a>
                </li>
            </ul>
            <img src="assets/admin.jpeg" class="userpict">
        </nav>
    </div>

    <div style="margin-bottom:120px" class="home" id="home">
        <div class="coverimage">
            <img src="assets/cover_admin.png" alt="">
        </div>
        <div class="content">
            <h2>"Highlighting the empowerment of freelancers and businesses"</h2><br>
            <p>An innovative and seamless platform that empowers dynamic and collaborative connections between
                freelancers and businesses, ensuring efficient and professional results.</p>
        </div>
    </div>
</body>

</html>